import { pgTable, text, serial, integer, timestamp, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Currency schema
export type Currency = {
  code: string;
  name: string;
  symbol: string;
};

// Conversion schema
export const conversions = pgTable("conversions", {
  id: serial("id").primaryKey(),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  fromAmount: real("from_amount").notNull(),
  toAmount: real("to_amount").notNull(),
  rate: real("rate").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertConversionSchema = createInsertSchema(conversions).omit({
  id: true,
  timestamp: true,
});

export type InsertConversion = z.infer<typeof insertConversionSchema>;
export type Conversion = typeof conversions.$inferSelect;

// Exchange Rate schema
export interface ExchangeRateResponse {
  success: boolean;
  timestamp: number;
  base: string;
  date: string;
  rates: Record<string, number>;
}

export const exchangeRateSchema = z.object({
  success: z.boolean(),
  timestamp: z.number(),
  base: z.string(),
  date: z.string(),
  rates: z.record(z.string(), z.number()),
});

// Rate alerts schema
export const rateAlerts = pgTable("rate_alerts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  targetRate: real("target_rate").notNull(),
  condition: text("condition").notNull(), // 'above' or 'below'
  isActive: boolean("is_active").notNull().default(true),
  lastTriggered: timestamp("last_triggered"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRateAlertSchema = createInsertSchema(rateAlerts).omit({
  id: true,
  lastTriggered: true,
  createdAt: true,
});

export type InsertRateAlert = z.infer<typeof insertRateAlertSchema>;
export type RateAlert = typeof rateAlerts.$inferSelect;

// Conversion history item for frontend
export interface ConversionHistoryItem {
  id: string;
  fromAmount: number;
  fromCurrency: string;
  toAmount: number;
  toCurrency: string;
  rate: number;
  timestamp: Date;
}
