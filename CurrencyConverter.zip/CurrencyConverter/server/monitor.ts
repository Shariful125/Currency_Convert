import { storage } from "./storage";
import { sendRateAlertEmail } from "./email";
import axios from "axios";

// Using a free, no-auth API for exchange rates
const EXCHANGE_API_BASE_URL = "https://open.er-api.com/v6/latest";

// Rate monitoring interval (5 minutes)
const MONITORING_INTERVAL = 5 * 60 * 1000;

export class RateMonitor {
  private intervalId: NodeJS.Timeout | null = null;
  private isRunning = false;

  start() {
    if (this.isRunning) {
      console.log("Rate monitor is already running");
      return;
    }

    console.log("Starting rate monitor...");
    this.isRunning = true;
    
    // Check immediately on start
    this.checkAlerts();
    
    // Then check every 5 minutes
    this.intervalId = setInterval(() => {
      this.checkAlerts();
    }, MONITORING_INTERVAL);
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
    console.log("Rate monitor stopped");
  }

  async checkAlerts() {
    try {
      console.log("Checking rate alerts...");
      const activeAlerts = await storage.getActiveRateAlerts();
      let triggeredCount = 0;

      for (const alert of activeAlerts) {
        try {
          // Get current rate for this alert
          const response = await axios.get(`${EXCHANGE_API_BASE_URL}/${alert.fromCurrency}`);
          const currentRate = response.data.rates[alert.toCurrency];
          
          if (!currentRate) {
            console.log(`No rate found for ${alert.fromCurrency}/${alert.toCurrency}`);
            continue;
          }

          // Check if alert condition is met
          const shouldTrigger = 
            (alert.condition === "above" && currentRate >= alert.targetRate) ||
            (alert.condition === "below" && currentRate <= alert.targetRate);

          if (shouldTrigger) {
            console.log(`Alert triggered for ${alert.email}: ${alert.fromCurrency}/${alert.toCurrency} ${alert.condition} ${alert.targetRate} (current: ${currentRate})`);
            
            // Send email notification
            const emailSent = await sendRateAlertEmail(
              alert.email,
              alert.fromCurrency,
              alert.toCurrency,
              currentRate,
              alert.targetRate,
              alert.condition
            );

            if (emailSent) {
              // Update the alert's last triggered time and deactivate it
              await storage.updateRateAlert(alert.id, {
                lastTriggered: new Date(),
                isActive: false
              });
              triggeredCount++;
            } else {
              console.error(`Failed to send email for alert ${alert.id}`);
            }
          }
        } catch (error) {
          console.error(`Error processing alert ${alert.id}:`, error);
        }
      }

      if (triggeredCount > 0) {
        console.log(`Triggered ${triggeredCount} out of ${activeAlerts.length} active alerts`);
      } else if (activeAlerts.length > 0) {
        console.log(`Checked ${activeAlerts.length} active alerts - no triggers`);
      }
    } catch (error) {
      console.error("Error checking rate alerts:", error);
    }
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      intervalMs: MONITORING_INTERVAL,
    };
  }
}

// Create singleton instance
export const rateMonitor = new RateMonitor();