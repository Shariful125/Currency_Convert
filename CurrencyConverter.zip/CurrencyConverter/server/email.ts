import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  console.warn("SENDGRID_API_KEY not found. Email notifications will be disabled.");
} else if (!process.env.SENDGRID_API_KEY.startsWith('SG.')) {
  console.warn("SENDGRID_API_KEY format appears incorrect. It should start with 'SG.' - Email notifications may not work properly.");
}

const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  try {
    if (!process.env.SENDGRID_API_KEY) {
      console.error("Cannot send email: SENDGRID_API_KEY not configured");
      return false;
    }

    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html,
    });
    console.log(`Email sent successfully to ${params.to}`);
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export async function sendRateAlertEmail(
  email: string,
  fromCurrency: string,
  toCurrency: string,
  currentRate: number,
  targetRate: number,
  condition: string
): Promise<boolean> {
  const subject = `Currency Alert: ${fromCurrency}/${toCurrency} Rate ${condition} ${targetRate}`;
  
  const text = `
Your currency rate alert has been triggered!

Currency Pair: ${fromCurrency} to ${toCurrency}
Target Rate: ${targetRate}
Current Rate: ${currentRate}
Condition: Rate went ${condition} your target

This alert was triggered at ${new Date().toLocaleString()}.

Best regards,
Currency Converter Team
  `;

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #2563eb;">Currency Rate Alert Triggered</h2>
      
      <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #1f2937;">Alert Details</h3>
        <p><strong>Currency Pair:</strong> ${fromCurrency} to ${toCurrency}</p>
        <p><strong>Target Rate:</strong> ${targetRate}</p>
        <p><strong>Current Rate:</strong> ${currentRate}</p>
        <p><strong>Condition:</strong> Rate went ${condition} your target</p>
        <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
      </div>
      
      <p>Your currency rate alert has been triggered! The ${fromCurrency}/${toCurrency} exchange rate has reached your specified condition.</p>
      
      <p style="color: #6b7280; font-size: 14px;">
        This is an automated message from your Currency Converter application.
      </p>
    </div>
  `;

  return await sendEmail({
    to: email,
    from: 'noreply@currencyconverter.com', // You should use a verified sender
    subject,
    text,
    html
  });
}