import { users, type User, type InsertUser, type InsertConversion, type Conversion, type InsertRateAlert, type RateAlert } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Conversion methods
  saveConversion(conversion: InsertConversion): Promise<Conversion>;
  getConversions(): Promise<Conversion[]>;
  getConversion(id: number): Promise<Conversion | undefined>;
  deleteConversion(id: number): Promise<void>;
  clearConversions(): Promise<void>;
  
  // Rate alert methods
  createRateAlert(alert: InsertRateAlert): Promise<RateAlert>;
  getRateAlerts(): Promise<RateAlert[]>;
  getRateAlertsByEmail(email: string): Promise<RateAlert[]>;
  updateRateAlert(id: number, updates: Partial<RateAlert>): Promise<RateAlert | undefined>;
  deleteRateAlert(id: number): Promise<void>;
  getActiveRateAlerts(): Promise<RateAlert[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private conversions: Map<number, Conversion>;
  private userCurrentId: number;
  private conversionCurrentId: number;

  constructor() {
    this.users = new Map();
    this.conversions = new Map();
    this.userCurrentId = 1;
    this.conversionCurrentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async saveConversion(insertConversion: InsertConversion): Promise<Conversion> {
    const id = this.conversionCurrentId++;
    const timestamp = new Date();
    const conversion: Conversion = { 
      ...insertConversion, 
      id, 
      timestamp 
    };
    this.conversions.set(id, conversion);
    return conversion;
  }
  
  async getConversions(): Promise<Conversion[]> {
    return Array.from(this.conversions.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }
  
  async getConversion(id: number): Promise<Conversion | undefined> {
    return this.conversions.get(id);
  }
  
  async deleteConversion(id: number): Promise<void> {
    this.conversions.delete(id);
  }
  
  async clearConversions(): Promise<void> {
    this.conversions.clear();
  }
  
  // Rate alert methods (not implemented in MemStorage)
  async createRateAlert(alert: InsertRateAlert): Promise<RateAlert> {
    throw new Error("Rate alerts require database storage");
  }
  
  async getRateAlerts(): Promise<RateAlert[]> {
    throw new Error("Rate alerts require database storage");
  }
  
  async getRateAlertsByEmail(email: string): Promise<RateAlert[]> {
    throw new Error("Rate alerts require database storage");
  }
  
  async updateRateAlert(id: number, updates: Partial<RateAlert>): Promise<RateAlert | undefined> {
    throw new Error("Rate alerts require database storage");
  }
  
  async deleteRateAlert(id: number): Promise<void> {
    throw new Error("Rate alerts require database storage");
  }
  
  async getActiveRateAlerts(): Promise<RateAlert[]> {
    throw new Error("Rate alerts require database storage");
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const { db } = await import("./db");
    const { users } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const { db } = await import("./db");
    const { users } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const { db } = await import("./db");
    const { users } = await import("@shared/schema");
    
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async saveConversion(insertConversion: InsertConversion): Promise<Conversion> {
    const { db } = await import("./db");
    const { conversions } = await import("@shared/schema");
    
    const [conversion] = await db
      .insert(conversions)
      .values(insertConversion)
      .returning();
    return conversion;
  }
  
  async getConversions(): Promise<Conversion[]> {
    const { db } = await import("./db");
    const { conversions } = await import("@shared/schema");
    const { desc } = await import("drizzle-orm");
    
    return await db.select().from(conversions).orderBy(desc(conversions.timestamp));
  }
  
  async getConversion(id: number): Promise<Conversion | undefined> {
    const { db } = await import("./db");
    const { conversions } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    const [conversion] = await db.select().from(conversions).where(eq(conversions.id, id));
    return conversion || undefined;
  }
  
  async deleteConversion(id: number): Promise<void> {
    const { db } = await import("./db");
    const { conversions } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    await db.delete(conversions).where(eq(conversions.id, id));
  }
  
  async clearConversions(): Promise<void> {
    const { db } = await import("./db");
    const { conversions } = await import("@shared/schema");
    
    await db.delete(conversions);
  }
  
  // Rate alert methods
  async createRateAlert(alert: InsertRateAlert): Promise<RateAlert> {
    const { db } = await import("./db");
    const { rateAlerts } = await import("@shared/schema");
    
    const [rateAlert] = await db
      .insert(rateAlerts)
      .values(alert)
      .returning();
    return rateAlert;
  }
  
  async getRateAlerts(): Promise<RateAlert[]> {
    const { db } = await import("./db");
    const { rateAlerts } = await import("@shared/schema");
    const { desc } = await import("drizzle-orm");
    
    return await db.select().from(rateAlerts).orderBy(desc(rateAlerts.createdAt));
  }
  
  async getRateAlertsByEmail(email: string): Promise<RateAlert[]> {
    const { db } = await import("./db");
    const { rateAlerts } = await import("@shared/schema");
    const { eq, desc } = await import("drizzle-orm");
    
    return await db.select().from(rateAlerts)
      .where(eq(rateAlerts.email, email))
      .orderBy(desc(rateAlerts.createdAt));
  }
  
  async updateRateAlert(id: number, updates: Partial<RateAlert>): Promise<RateAlert | undefined> {
    const { db } = await import("./db");
    const { rateAlerts } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    const [updated] = await db
      .update(rateAlerts)
      .set(updates)
      .where(eq(rateAlerts.id, id))
      .returning();
    return updated || undefined;
  }
  
  async deleteRateAlert(id: number): Promise<void> {
    const { db } = await import("./db");
    const { rateAlerts } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    await db.delete(rateAlerts).where(eq(rateAlerts.id, id));
  }
  
  async getActiveRateAlerts(): Promise<RateAlert[]> {
    const { db } = await import("./db");
    const { rateAlerts } = await import("@shared/schema");
    const { eq } = await import("drizzle-orm");
    
    return await db.select().from(rateAlerts).where(eq(rateAlerts.isActive, true));
  }
}

export const storage = new DatabaseStorage();
