import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { exchangeRateSchema, insertConversionSchema, insertRateAlertSchema } from "@shared/schema";
import axios from "axios";
import { sendRateAlertEmail } from "./email";
import { rateMonitor } from "./monitor";

// Using a free, no-auth API for exchange rates
const EXCHANGE_API_BASE_URL = "https://open.er-api.com/v6/latest";

// Cache exchange rates for 1 hour to limit API calls
const ratesCache: Record<string, { timestamp: number; data: any }> = {};
const CACHE_DURATION = 60 * 60 * 1000; // 1 hour in milliseconds

export async function registerRoutes(app: Express): Promise<Server> {
  // Get latest exchange rates
  app.get("/api/rates", async (req, res) => {
    try {
      const base = (req.query.base as string) || "USD";
      
      // Check if we have cached data that's still valid
      const cacheKey = `rates_${base}`;
      const cachedData = ratesCache[cacheKey];
      const now = Date.now();
      
      if (cachedData && now - cachedData.timestamp < CACHE_DURATION) {
        return res.json(cachedData.data);
      }
      
      // Fetch fresh data if no cache or cache expired
      const response = await axios.get(`${EXCHANGE_API_BASE_URL}/${base}`);
      
      // Transform response to match our schema
      const transformedData = {
        success: true,
        timestamp: Date.now(),
        base: response.data.base_code,
        date: new Date().toISOString().split('T')[0],
        rates: response.data.rates
      };
      
      const parsedData = exchangeRateSchema.parse(transformedData);
      
      // Update cache
      ratesCache[cacheKey] = {
        timestamp: now,
        data: parsedData
      };
      
      res.json(parsedData);
    } catch (error) {
      console.error("Error fetching exchange rates:", error);
      res.status(500).json({ 
        message: "Failed to fetch exchange rates",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  
  // Get supported currencies
  app.get("/api/currencies", async (_req, res) => {
    try {
      const currencies = [
        { code: "USD", name: "US Dollar", symbol: "$" },
        { code: "EUR", name: "Euro", symbol: "€" },
        { code: "GBP", name: "British Pound", symbol: "£" },
        { code: "JPY", name: "Japanese Yen", symbol: "¥" },
        { code: "CAD", name: "Canadian Dollar", symbol: "C$" },
        { code: "AUD", name: "Australian Dollar", symbol: "A$" },
        { code: "CHF", name: "Swiss Franc", symbol: "Fr" },
        { code: "CNY", name: "Chinese Yuan", symbol: "¥" },
        { code: "INR", name: "Indian Rupee", symbol: "₹" },
        { code: "MXN", name: "Mexican Peso", symbol: "$" },
        { code: "SGD", name: "Singapore Dollar", symbol: "S$" },
        { code: "NZD", name: "New Zealand Dollar", symbol: "NZ$" },
        { code: "BRL", name: "Brazilian Real", symbol: "R$" },
      ];
      
      res.json({ currencies });
    } catch (error) {
      console.error("Error fetching currencies:", error);
      res.status(500).json({ 
        message: "Failed to fetch currencies",
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });
  
  // Save conversion to history
  app.post("/api/conversions", async (req, res) => {
    try {
      const conversionData = insertConversionSchema.parse(req.body);
      const savedConversion = await storage.saveConversion(conversionData);
      res.status(201).json(savedConversion);
    } catch (error) {
      console.error("Error saving conversion:", error);
      res.status(400).json({ 
        message: "Failed to save conversion",
        error: error instanceof Error ? error.message : "Invalid data provided"
      });
    }
  });
  
  // Get conversion history
  app.get("/api/conversions", async (_req, res) => {
    try {
      const conversions = await storage.getConversions();
      res.json({ conversions });
    } catch (error) {
      console.error("Error fetching conversions:", error);
      res.status(500).json({ 
        message: "Failed to fetch conversion history",
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });
  
  // Delete a conversion
  app.delete("/api/conversions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid conversion ID" });
      }
      
      await storage.deleteConversion(id);
      res.status(200).json({ message: "Conversion deleted successfully" });
    } catch (error) {
      console.error("Error deleting conversion:", error);
      res.status(500).json({ 
        message: "Failed to delete conversion",
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });
  
  // Clear all conversions
  app.delete("/api/conversions", async (_req, res) => {
    try {
      await storage.clearConversions();
      res.status(200).json({ message: "All conversions cleared successfully" });
    } catch (error) {
      console.error("Error clearing conversions:", error);
      res.status(500).json({ 
        message: "Failed to clear conversions",
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Rate Alert Routes
  
  // Create a new rate alert
  app.post("/api/rate-alerts", async (req, res) => {
    try {
      const alertData = insertRateAlertSchema.parse(req.body);
      const savedAlert = await storage.createRateAlert(alertData);
      res.status(201).json(savedAlert);
    } catch (error) {
      console.error("Error creating rate alert:", error);
      res.status(400).json({
        message: "Failed to create rate alert",
        error: error instanceof Error ? error.message : "Invalid data provided"
      });
    }
  });

  // Get all rate alerts
  app.get("/api/rate-alerts", async (_req, res) => {
    try {
      const alerts = await storage.getRateAlerts();
      res.json({ alerts });
    } catch (error) {
      console.error("Error fetching rate alerts:", error);
      res.status(500).json({
        message: "Failed to fetch rate alerts",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get rate alerts by email
  app.get("/api/rate-alerts/email/:email", async (req, res) => {
    try {
      const { email } = req.params;
      const alerts = await storage.getRateAlertsByEmail(email);
      res.json({ alerts });
    } catch (error) {
      console.error("Error fetching rate alerts by email:", error);
      res.status(500).json({
        message: "Failed to fetch rate alerts",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Update a rate alert
  app.patch("/api/rate-alerts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid alert ID" });
      }

      const updates = req.body;
      const updatedAlert = await storage.updateRateAlert(id, updates);
      
      if (!updatedAlert) {
        return res.status(404).json({ message: "Rate alert not found" });
      }
      
      res.json(updatedAlert);
    } catch (error) {
      console.error("Error updating rate alert:", error);
      res.status(500).json({
        message: "Failed to update rate alert",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Delete a rate alert
  app.delete("/api/rate-alerts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid alert ID" });
      }

      await storage.deleteRateAlert(id);
      res.status(200).json({ message: "Rate alert deleted successfully" });
    } catch (error) {
      console.error("Error deleting rate alert:", error);
      res.status(500).json({
        message: "Failed to delete rate alert",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Monitor rate alerts (this will be called periodically)
  app.post("/api/rate-alerts/check", async (_req, res) => {
    try {
      const activeAlerts = await storage.getActiveRateAlerts();
      let triggeredCount = 0;

      for (const alert of activeAlerts) {
        try {
          // Get current rate for this alert
          const response = await axios.get(`${EXCHANGE_API_BASE_URL}/${alert.fromCurrency}`);
          const currentRate = response.data.rates[alert.toCurrency];
          
          if (!currentRate) continue;

          // Check if alert condition is met
          const shouldTrigger = 
            (alert.condition === "above" && currentRate >= alert.targetRate) ||
            (alert.condition === "below" && currentRate <= alert.targetRate);

          if (shouldTrigger) {
            // Send email notification
            const emailSent = await sendRateAlertEmail(
              alert.email,
              alert.fromCurrency,
              alert.toCurrency,
              currentRate,
              alert.targetRate,
              alert.condition
            );

            if (emailSent) {
              // Update the alert's last triggered time and deactivate it
              await storage.updateRateAlert(alert.id, {
                lastTriggered: new Date(),
                isActive: false
              });
              triggeredCount++;
              console.log(`Alert triggered for ${alert.email}: ${alert.fromCurrency}/${alert.toCurrency}`);
            }
          }
        } catch (error) {
          console.error(`Error processing alert ${alert.id}:`, error);
        }
      }

      res.json({ 
        message: "Rate alerts checked successfully",
        triggeredCount,
        totalChecked: activeAlerts.length
      });
    } catch (error) {
      console.error("Error checking rate alerts:", error);
      res.status(500).json({
        message: "Failed to check rate alerts",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Monitor status and control routes
  app.get("/api/monitor/status", (_req, res) => {
    try {
      const status = rateMonitor.getStatus();
      res.json({
        monitoring: status,
        message: status.isRunning ? "Rate monitoring is active" : "Rate monitoring is stopped"
      });
    } catch (error) {
      console.error("Error getting monitor status:", error);
      res.status(500).json({
        message: "Failed to get monitor status",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Manual trigger for checking alerts (for testing)
  app.post("/api/monitor/check-now", async (_req, res) => {
    try {
      await rateMonitor.checkAlerts();
      res.json({ message: "Alert check completed successfully" });
    } catch (error) {
      console.error("Error in manual alert check:", error);
      res.status(500).json({
        message: "Failed to check alerts",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
