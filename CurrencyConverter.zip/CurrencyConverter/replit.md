# Currency Converter Application

## Overview
A real-time currency conversion calculator with email rate alerts functionality.

## Project Architecture
- **Frontend**: React with TypeScript, Tailwind CSS, and shadcn components
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **API**: Free exchange rates from open.er-api.com
- **Email**: SendGrid for rate alert notifications

## Current Features
- Real-time currency conversion
- Support for 13+ currencies
- Conversion history tracking
- Light/dark mode toggle
- Rate alert notifications via email

## Recent Changes
- **2024-01-20**: Fixed exchange rate API connection issues by switching to open.er-api.com
- **2024-01-20**: Added PostgreSQL database support for persistent data
- **2024-01-20**: Implemented complete email rate alert system with:
  - Database schema for rate alerts
  - Email notifications via SendGrid
  - Automatic monitoring every 5 minutes
  - Frontend interface for creating and managing alerts
  - Navigation between converter and alerts pages

## User Preferences
- Keep UI simple and intuitive
- Use reliable, free APIs when possible
- Focus on real-time data accuracy