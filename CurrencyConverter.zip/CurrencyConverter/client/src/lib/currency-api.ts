import { ExchangeRateResponse } from "@shared/schema";

// Base URL for exchange rate API
const EXCHANGE_API_BASE_URL = "/api"; // Proxied through our server

// Get exchange rates
export async function fetchExchangeRates(base: string = "USD"): Promise<ExchangeRateResponse> {
  try {
    const response = await fetch(`${EXCHANGE_API_BASE_URL}/rates?base=${base}`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch exchange rates: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error fetching exchange rates:", error);
    throw error;
  }
}

// Get available currencies
export async function fetchCurrencies() {
  try {
    const response = await fetch(`${EXCHANGE_API_BASE_URL}/currencies`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch currencies: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error fetching currencies:", error);
    throw error;
  }
}

// Save conversion to history
export async function saveConversion(conversion: {
  fromCurrency: string;
  toCurrency: string;
  fromAmount: number;
  toAmount: number;
  rate: number;
}) {
  try {
    const response = await fetch(`${EXCHANGE_API_BASE_URL}/conversions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(conversion),
    });
    
    if (!response.ok) {
      throw new Error(`Failed to save conversion: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error saving conversion:", error);
    throw error;
  }
}

// Get conversion history
export async function fetchConversionHistory() {
  try {
    const response = await fetch(`${EXCHANGE_API_BASE_URL}/conversions`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch conversion history: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error fetching conversion history:", error);
    throw error;
  }
}

// Delete conversion from history
export async function deleteConversion(id: number) {
  try {
    const response = await fetch(`${EXCHANGE_API_BASE_URL}/conversions/${id}`, {
      method: "DELETE",
    });
    
    if (!response.ok) {
      throw new Error(`Failed to delete conversion: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error deleting conversion:", error);
    throw error;
  }
}

// Clear all conversion history
export async function clearConversionHistory() {
  try {
    const response = await fetch(`${EXCHANGE_API_BASE_URL}/conversions`, {
      method: "DELETE",
    });
    
    if (!response.ok) {
      throw new Error(`Failed to clear conversion history: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error clearing conversion history:", error);
    throw error;
  }
}
