import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { Currency, ConversionHistoryItem } from "@shared/schema";
import ConverterCard from "@/components/converter-card";
import ResultCard from "@/components/result-card";
import HistoryCard from "@/components/history-card";
import ErrorToast from "@/components/error-toast";
import LoadingOverlay from "@/components/loading-overlay";
import { ModeToggle } from "@/components/mode-toggle";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";

export default function CurrencyConverter() {
  const { toast } = useToast();
  const [showResult, setShowResult] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // State for conversion
  const [amount, setAmount] = useState<string>("");
  const [fromCurrency, setFromCurrency] = useState<Currency>({ 
    code: "USD", 
    name: "US Dollar", 
    symbol: "$" 
  });
  const [toCurrency, setToCurrency] = useState<Currency>({ 
    code: "EUR", 
    name: "Euro", 
    symbol: "€" 
  });
  const [rate, setRate] = useState<number | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [result, setResult] = useState<{
    fromAmount: number;
    toAmount: number;
    fromCurrency: string;
    toCurrency: string;
    rate: number;
  } | null>(null);
  
  // Conversion history
  const [history, setHistory] = useState<ConversionHistoryItem[]>([]);

  // Fetch currencies
  const { data: currenciesData, isLoading: isCurrenciesLoading } = useQuery({
    queryKey: ['/api/currencies'],
    staleTime: Infinity, // These don't change often
  });

  // Load exchange rates when currencies change
  useEffect(() => {
    if (fromCurrency) {
      fetchExchangeRate();
    }
  }, [fromCurrency, toCurrency]);

  // Format the last updated time
  const formatLastUpdated = () => {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12;
    const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
    
    return `Today at ${formattedHours}:${formattedMinutes} ${ampm}`;
  };

  // Fetch exchange rate
  const fetchExchangeRate = async () => {
    if (!fromCurrency || !toCurrency) return;
    
    setIsLoading(true);
    try {
      const response = await apiRequest(
        'GET', 
        `/api/rates?base=${fromCurrency.code}`
      );
      const data = await response.json();
      
      if (!data.success) {
        throw new Error("Failed to fetch exchange rates");
      }
      
      const exchangeRate = data.rates[toCurrency.code];
      setRate(exchangeRate);
      setLastUpdated(formatLastUpdated());
      setError(null);
    } catch (err) {
      console.error("Error fetching exchange rates:", err);
      setError("Unable to fetch exchange rates. Please try again later.");
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to fetch exchange rates. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle conversion
  const handleConvert = (amount: number, from: Currency, to: Currency) => {
    if (!rate) {
      setError("Exchange rate not available");
      return;
    }
    
    const convertedAmount = amount * rate;
    setResult({
      fromAmount: amount,
      toAmount: convertedAmount,
      fromCurrency: from.code,
      toCurrency: to.code,
      rate: rate
    });
    setShowResult(true);
  };

  // Add to history
  const addToHistory = () => {
    if (!result) return;
    
    const historyItem: ConversionHistoryItem = {
      id: Date.now().toString(),
      fromAmount: result.fromAmount,
      fromCurrency: result.fromCurrency,
      toAmount: result.toAmount,
      toCurrency: result.toCurrency,
      rate: result.rate,
      timestamp: new Date()
    };
    
    setHistory([historyItem, ...history]);
    
    // Save to server (optional, will stay in client memory for now)
    saveToDB(historyItem);
  };
  
  // Save to database through API
  const saveToDB = async (item: ConversionHistoryItem) => {
    try {
      await apiRequest('POST', '/api/conversions', {
        fromCurrency: item.fromCurrency,
        toCurrency: item.toCurrency,
        fromAmount: item.fromAmount,
        toAmount: item.toAmount,
        rate: item.rate
      });
    } catch (err) {
      console.error("Error saving conversion:", err);
    }
  };

  // Remove from history
  const removeFromHistory = (id: string) => {
    setHistory(history.filter(item => item.id !== id));
  };

  // Clear all history
  const clearHistory = () => {
    setHistory([]);
    
    // Clear on server too
    try {
      apiRequest('DELETE', '/api/conversions');
    } catch (err) {
      console.error("Error clearing history:", err);
    }
  };

  // Switch currencies
  const switchCurrencies = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
  };

  // Start new conversion
  const newConversion = () => {
    setShowResult(false);
    setAmount("");
  };

  return (
    <div className="bg-gray-100 dark:bg-gray-900 font-sans min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <header className="mb-8">
          <div className="flex justify-between items-center">
            <div className="text-center flex-1">
              <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100 flex items-center justify-center gap-2">
                <span className="material-icons text-primary">currency_exchange</span>
                Currency Converter
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                Convert currencies with real-time exchange rates
              </p>
            </div>
            <div className="flex gap-2">
              <Link href="/alerts">
                <Button variant="outline" className="flex items-center gap-2">
                  <Bell className="h-4 w-4" />
                  Rate Alerts
                </Button>
              </Link>
              <ModeToggle />
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main content */}
          <div className="lg:col-span-2">
            {!showResult ? (
              <ConverterCard
                currencies={currenciesData?.currencies || []}
                amount={amount}
                setAmount={setAmount}
                fromCurrency={fromCurrency}
                setFromCurrency={setFromCurrency}
                toCurrency={toCurrency}
                setToCurrency={setToCurrency}
                rate={rate}
                lastUpdated={lastUpdated}
                onConvert={handleConvert}
                onSwitchCurrencies={switchCurrencies}
                onRefreshRates={fetchExchangeRate}
                isLoading={isCurrenciesLoading}
              />
            ) : (
              <ResultCard
                result={result}
                onSaveToHistory={addToHistory}
                onNewConversion={newConversion}
              />
            )}
          </div>

          {/* History Card */}
          <HistoryCard
            history={history}
            onClearHistory={clearHistory}
            onRemoveItem={removeFromHistory}
          />
        </div>

        {/* Error Toast */}
        {error && (
          <ErrorToast
            message={error}
            onClose={() => setError(null)}
          />
        )}

        {/* Loading Overlay */}
        {isLoading && <LoadingOverlay />}
      </div>
    </div>
  );
}
