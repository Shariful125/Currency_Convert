import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bell, Plus, X, ArrowLeft } from "lucide-react";
import RateAlertForm from "@/components/rate-alert-form";
import RateAlertsList from "@/components/rate-alerts-list";
import { ModeToggle } from "@/components/mode-toggle";

export default function RateAlertsPage() {
  const [showForm, setShowForm] = useState(false);

  // Fetch currencies for the form
  const { data: currenciesData, isLoading: isCurrenciesLoading } = useQuery({
    queryKey: ['/api/currencies'],
    staleTime: Infinity,
  });

  return (
    <div className="bg-gray-100 dark:bg-gray-900 font-sans min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <header className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Link href="/">
                  <Button variant="ghost" size="sm" className="p-2">
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </Link>
                <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100 flex items-center gap-2">
                  <Bell className="text-primary" />
                  Rate Alerts
                </h1>
              </div>
              <p className="text-gray-600 dark:text-gray-400">
                Get notified when exchange rates meet your target conditions
              </p>
            </div>
            <ModeToggle />
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Form or Create Button */}
          <div>
            {!showForm ? (
              <Card className="bg-white dark:bg-gray-800 shadow-md">
                <CardContent className="p-6 text-center">
                  <Bell className="h-16 w-16 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Create Your First Alert</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Set up email notifications for when currency rates reach your target levels
                  </p>
                  <Button
                    onClick={() => setShowForm(true)}
                    className="w-full"
                    disabled={isCurrenciesLoading}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create Rate Alert
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowForm(false)}
                  className="absolute -top-2 -right-2 z-10 rounded-full p-2"
                >
                  <X className="h-4 w-4" />
                </Button>
                <RateAlertForm
                  currencies={currenciesData?.currencies || []}
                  onClose={() => setShowForm(false)}
                />
              </div>
            )}
          </div>

          {/* Right Column - Alerts List */}
          <div>
            <RateAlertsList />
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-8">
          <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-2">
                How Rate Alerts Work
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-blue-800 dark:text-blue-200">
                <div>
                  <strong>1. Set Your Target</strong>
                  <p>Choose currency pair, target rate, and condition (above/below)</p>
                </div>
                <div>
                  <strong>2. Monitor Automatically</strong>
                  <p>Our system checks rates every few minutes during market hours</p>
                </div>
                <div>
                  <strong>3. Get Notified</strong>
                  <p>Receive instant email when your target rate is reached</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}