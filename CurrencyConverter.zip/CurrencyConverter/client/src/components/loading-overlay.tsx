import { Loader2 } from "lucide-react";

export default function LoadingOverlay() {
  return (
    <div
      className="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center z-50"
    >
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg flex items-center">
        <Loader2 className="animate-spin text-primary h-5 w-5 mr-3" />
        <p className="text-gray-800 dark:text-gray-200">Loading exchange rates...</p>
      </div>
    </div>
  );
}
