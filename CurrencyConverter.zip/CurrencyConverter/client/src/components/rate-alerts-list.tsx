import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Bell, Mail, Trash2, Search, ToggleLeft, ToggleRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { RateAlert } from "@shared/schema";

export default function RateAlertsList() {
  const { toast } = useToast();
  const [emailFilter, setEmailFilter] = useState("");

  // Fetch rate alerts
  const { data: alertsData, isLoading } = useQuery({
    queryKey: ['/api/rate-alerts'],
    staleTime: 30000, // Cache for 30 seconds
  });

  // Delete alert mutation
  const deleteAlertMutation = useMutation({
    mutationFn: async (alertId: number) => {
      await apiRequest('DELETE', `/api/rate-alerts/${alertId}`);
    },
    onSuccess: () => {
      toast({
        title: "Alert Deleted",
        description: "Rate alert has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/rate-alerts'] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete rate alert.",
      });
    }
  });

  // Toggle alert status mutation
  const toggleAlertMutation = useMutation({
    mutationFn: async ({ alertId, isActive }: { alertId: number; isActive: boolean }) => {
      await apiRequest('PATCH', `/api/rate-alerts/${alertId}`, { isActive });
    },
    onSuccess: () => {
      toast({
        title: "Alert Updated",
        description: "Rate alert status has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/rate-alerts'] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update rate alert.",
      });
    }
  });

  const alerts: RateAlert[] = alertsData?.alerts || [];

  // Filter alerts by email
  const filteredAlerts = emailFilter 
    ? alerts.filter(alert => alert.email.toLowerCase().includes(emailFilter.toLowerCase()))
    : alerts;

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString() + ' ' + new Date(date).toLocaleTimeString();
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            <span className="ml-2 text-gray-600 dark:text-gray-400">Loading alerts...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white dark:bg-gray-800 shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Bell className="h-5 w-5 text-primary" />
          Rate Alerts ({alerts.length})
        </CardTitle>
        
        {/* Email Filter */}
        <div className="flex items-center gap-2 mt-4">
          <Label htmlFor="emailFilter" className="text-sm font-medium">
            Filter by Email:
          </Label>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              id="emailFilter"
              type="email"
              value={emailFilter}
              onChange={(e) => setEmailFilter(e.target.value)}
              className="pl-10"
              placeholder="Search by email..."
            />
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {filteredAlerts.length === 0 ? (
          <div className="text-center py-8">
            <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400 mb-2">
              {emailFilter ? "No alerts found for this email" : "No rate alerts created yet"}
            </p>
            <p className="text-sm text-gray-400">
              {emailFilter ? "Try a different email address" : "Create your first alert to get notified of rate changes"}
            </p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {filteredAlerts.map((alert) => (
              <div
                key={alert.id}
                className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-gray-50 dark:bg-gray-900"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <span className="font-medium text-sm">{alert.email}</span>
                      <Badge 
                        variant={alert.isActive ? "default" : "secondary"}
                        className="text-xs"
                      >
                        {alert.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    
                    <div className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                      <span className="font-medium">
                        {alert.fromCurrency}/{alert.toCurrency}
                      </span>
                      {" "}goes{" "}
                      <span className="font-medium text-primary">
                        {alert.condition}
                      </span>
                      {" "}
                      <span className="font-medium">
                        {alert.targetRate}
                      </span>
                    </div>
                    
                    <div className="text-xs text-gray-500 space-y-1">
                      <div>Created: {formatDate(alert.createdAt)}</div>
                      {alert.lastTriggered && (
                        <div>Last triggered: {formatDate(alert.lastTriggered)}</div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 ml-4">
                    {/* Toggle Active Status */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleAlertMutation.mutate({
                        alertId: alert.id,
                        isActive: !alert.isActive
                      })}
                      disabled={toggleAlertMutation.isPending}
                      className="p-1"
                    >
                      {alert.isActive ? (
                        <ToggleRight className="h-4 w-4 text-green-600" />
                      ) : (
                        <ToggleLeft className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                    
                    {/* Delete Button */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteAlertMutation.mutate(alert.id)}
                      disabled={deleteAlertMutation.isPending}
                      className="p-1 text-red-600 hover:text-red-800 hover:bg-red-50 dark:hover:bg-red-950"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}