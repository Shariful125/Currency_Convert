import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, HistoryIcon, Plus } from "lucide-react";

interface ResultCardProps {
  result: {
    fromAmount: number;
    toAmount: number;
    fromCurrency: string;
    toCurrency: string;
    rate: number;
  } | null;
  onSaveToHistory: () => void;
  onNewConversion: () => void;
}

export default function ResultCard({
  result,
  onSaveToHistory,
  onNewConversion,
}: ResultCardProps) {
  if (!result) return null;

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-0 mb-6">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">
          Conversion Result
        </h2>
        
        <div className="flex flex-col space-y-2 mb-6">
          <div className="flex justify-between items-center">
            <span className="text-gray-600 dark:text-gray-400">
              {result.fromAmount.toFixed(2)} {result.fromCurrency}
            </span>
            <ArrowRight className="text-gray-400 h-5 w-5" />
            <span className="text-2xl font-bold text-gray-800 dark:text-gray-100">
              {result.toAmount.toFixed(2)} {result.toCurrency}
            </span>
          </div>
          <div className="border-t border-gray-200 dark:border-gray-700 pt-2 text-sm text-gray-500 dark:text-gray-400">
            <span>
              Based on the exchange rate: 1 {result.fromCurrency} = {result.rate.toFixed(4)} {result.toCurrency}
            </span>
          </div>
        </div>
        
        <div className="flex justify-between">
          <Button
            variant="outline"
            className="text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600"
            onClick={onSaveToHistory}
          >
            <HistoryIcon className="h-4 w-4 mr-1" />
            Save to History
          </Button>
          
          <Button
            variant="default"
            className="bg-primary text-primary-foreground hover:bg-primary-600"
            onClick={onNewConversion}
          >
            <Plus className="h-4 w-4 mr-1" />
            New Conversion
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
