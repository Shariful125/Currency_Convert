import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Currency } from "@shared/schema";
import { Bell, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface RateAlertFormProps {
  currencies: Currency[];
  onClose?: () => void;
}

export default function RateAlertForm({ currencies, onClose }: RateAlertFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    email: "",
    fromCurrency: "",
    toCurrency: "",
    targetRate: "",
    condition: "above" as "above" | "below"
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.email) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }

    if (!formData.fromCurrency) {
      newErrors.fromCurrency = "From currency is required";
    }

    if (!formData.toCurrency) {
      newErrors.toCurrency = "To currency is required";
    }

    if (formData.fromCurrency === formData.toCurrency) {
      newErrors.toCurrency = "From and to currencies must be different";
    }

    if (!formData.targetRate) {
      newErrors.targetRate = "Target rate is required";
    } else if (parseFloat(formData.targetRate) <= 0) {
      newErrors.targetRate = "Target rate must be greater than 0";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      await apiRequest('POST', '/api/rate-alerts', {
        email: formData.email,
        fromCurrency: formData.fromCurrency,
        toCurrency: formData.toCurrency,
        targetRate: parseFloat(formData.targetRate),
        condition: formData.condition,
        isActive: true
      });

      toast({
        title: "Rate Alert Created",
        description: `You'll receive an email when ${formData.fromCurrency}/${formData.toCurrency} goes ${formData.condition} ${formData.targetRate}`,
      });

      // Reset form
      setFormData({
        email: "",
        fromCurrency: "",
        toCurrency: "",
        targetRate: "",
        condition: "above"
      });

      // Invalidate alerts cache
      queryClient.invalidateQueries({ queryKey: ['/api/rate-alerts'] });
      
      if (onClose) {
        onClose();
      }
    } catch (error) {
      console.error("Error creating rate alert:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create rate alert. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="bg-white dark:bg-gray-800 shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Bell className="h-5 w-5 text-primary" />
          Create Rate Alert
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email Input */}
          <div>
            <Label htmlFor="email" className="text-sm font-medium">
              Email Address
            </Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className={`pl-10 ${errors.email ? 'border-red-500' : ''}`}
                placeholder="your@email.com"
              />
            </div>
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">{errors.email}</p>
            )}
          </div>

          {/* Currency Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="fromCurrency" className="text-sm font-medium">
                From Currency
              </Label>
              <Select
                value={formData.fromCurrency}
                onValueChange={(value) => setFormData(prev => ({ ...prev, fromCurrency: value }))}
              >
                <SelectTrigger className={errors.fromCurrency ? 'border-red-500' : ''}>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.code} - {currency.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.fromCurrency && (
                <p className="text-red-500 text-xs mt-1">{errors.fromCurrency}</p>
              )}
            </div>

            <div>
              <Label htmlFor="toCurrency" className="text-sm font-medium">
                To Currency
              </Label>
              <Select
                value={formData.toCurrency}
                onValueChange={(value) => setFormData(prev => ({ ...prev, toCurrency: value }))}
              >
                <SelectTrigger className={errors.toCurrency ? 'border-red-500' : ''}>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.code} - {currency.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.toCurrency && (
                <p className="text-red-500 text-xs mt-1">{errors.toCurrency}</p>
              )}
            </div>
          </div>

          {/* Alert Condition */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="condition" className="text-sm font-medium">
                Alert When Rate Goes
              </Label>
              <Select
                value={formData.condition}
                onValueChange={(value: "above" | "below") => setFormData(prev => ({ ...prev, condition: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="above">Above</SelectItem>
                  <SelectItem value="below">Below</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="targetRate" className="text-sm font-medium">
                Target Rate
              </Label>
              <Input
                id="targetRate"
                type="number"
                step="0.0001"
                value={formData.targetRate}
                onChange={(e) => setFormData(prev => ({ ...prev, targetRate: e.target.value }))}
                className={errors.targetRate ? 'border-red-500' : ''}
                placeholder="0.0000"
              />
              {errors.targetRate && (
                <p className="text-red-500 text-xs mt-1">{errors.targetRate}</p>
              )}
            </div>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Creating Alert..." : "Create Rate Alert"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}