import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Currency } from "@shared/schema";
import { RefreshCcw, Calculator, SquareSplitHorizontal } from "lucide-react";

interface ConverterCardProps {
  currencies: Currency[];
  amount: string;
  setAmount: (amount: string) => void;
  fromCurrency: Currency;
  setFromCurrency: (currency: Currency) => void;
  toCurrency: Currency;
  setToCurrency: (currency: Currency) => void;
  rate: number | null;
  lastUpdated: string | null;
  onConvert: (amount: number, from: Currency, to: Currency) => void;
  onSwitchCurrencies: () => void;
  onRefreshRates: () => void;
  isLoading: boolean;
}

export default function ConverterCard({
  currencies,
  amount,
  setAmount,
  fromCurrency,
  setFromCurrency,
  toCurrency,
  setToCurrency,
  rate,
  lastUpdated,
  onConvert,
  onSwitchCurrencies,
  onRefreshRates,
  isLoading,
}: ConverterCardProps) {
  const [amountError, setAmountError] = useState<string | null>(null);

  // Validate amount input
  const validateAmount = (value: string) => {
    const numberValue = parseFloat(value);
    if (!value || isNaN(numberValue) || numberValue <= 0) {
      setAmountError("Please enter a valid amount");
      return false;
    }
    setAmountError(null);
    return true;
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateAmount(amount)) {
      onConvert(parseFloat(amount), fromCurrency, toCurrency);
    }
  };

  // Find currency object by code
  const findCurrencyByCode = (code: string) => {
    return currencies.find(c => c.code === code) || fromCurrency;
  };

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-0 mb-6">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {/* Amount Input */}
            <div className="relative">
              <Label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Amount
              </Label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 dark:text-gray-400 sm:text-sm">
                    {fromCurrency?.symbol || "$"}
                  </span>
                </div>
                <Input
                  type="number"
                  id="amount"
                  value={amount}
                  onChange={(e) => {
                    setAmount(e.target.value);
                    validateAmount(e.target.value);
                  }}
                  className={`pl-7 pr-12 ${amountError ? 'border-red-500' : ''}`}
                  placeholder="0.00"
                  aria-label="Amount to convert"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 dark:text-gray-400 sm:text-sm">
                    {fromCurrency?.code || "USD"}
                  </span>
                </div>
              </div>
              {amountError && (
                <p className="mt-1 text-xs text-red-500">{amountError}</p>
              )}
            </div>

            {/* Currency Selection */}
            <div className="grid grid-cols-5 gap-2">
              {/* From Currency */}
              <div className="col-span-2">
                <Label htmlFor="fromCurrency" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  From
                </Label>
                <Select
                  value={fromCurrency?.code}
                  onValueChange={(value) => setFromCurrency(findCurrencyByCode(value))}
                  disabled={isLoading}
                >
                  <SelectTrigger id="fromCurrency" className="w-full">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.code} - {currency.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Switch Button */}
              <div className="flex items-end justify-center">
                <Button
                  type="button"
                  variant="default"
                  size="icon"
                  className="rounded-full bg-primary hover:bg-primary-600 text-primary-foreground"
                  onClick={onSwitchCurrencies}
                  disabled={isLoading}
                >
                  <SquareSplitHorizontal className="h-4 w-4" />
                  <span className="sr-only">Switch currencies</span>
                </Button>
              </div>

              {/* To Currency */}
              <div className="col-span-2">
                <Label htmlFor="toCurrency" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  To
                </Label>
                <Select
                  value={toCurrency?.code}
                  onValueChange={(value) => setToCurrency(findCurrencyByCode(value))}
                  disabled={isLoading}
                >
                  <SelectTrigger id="toCurrency" className="w-full">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.code} - {currency.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Current Rate */}
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Current Exchange Rate</p>
                <p className="text-lg font-medium dark:text-gray-200">
                  {rate 
                    ? `1 ${fromCurrency?.code} = ${rate.toFixed(4)} ${toCurrency?.code}`
                    : "Loading exchange rate..."}
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="text-primary-700 bg-primary-100 dark:bg-primary-900 dark:text-primary-300 hover:bg-primary-200"
                onClick={onRefreshRates}
                disabled={isLoading}
              >
                <RefreshCcw className="h-4 w-4 mr-1" />
                Refresh
              </Button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
              {lastUpdated ? `Last updated: ${lastUpdated}` : "Fetching exchange rates..."}
            </p>
          </div>

          {/* Convert Button */}
          <Button
            type="submit"
            className="w-full justify-center items-center py-6 bg-primary text-primary-foreground hover:bg-primary-600"
            disabled={isLoading || !rate}
          >
            <Calculator className="h-5 w-5 mr-2" />
            Convert
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
