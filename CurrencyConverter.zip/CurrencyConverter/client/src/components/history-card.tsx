import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X } from "lucide-react";
import { ConversionHistoryItem } from "@shared/schema";

interface HistoryCardProps {
  history: ConversionHistoryItem[];
  onClearHistory: () => void;
  onRemoveItem: (id: string) => void;
}

export default function HistoryCard({
  history,
  onClearHistory,
  onRemoveItem,
}: HistoryCardProps) {
  // Format timestamp function
  const formatTimestamp = (date: Date) => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12;
    const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
    
    return `Today at ${formattedHours}:${formattedMinutes} ${ampm}`;
  };

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-0 h-full">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
            Conversion History
          </h2>
          {history.length > 0 && (
            <Button
              variant="ghost"
              className="text-primary hover:text-primary-800 text-sm font-medium"
              onClick={onClearHistory}
            >
              Clear All
            </Button>
          )}
        </div>
        
        <div className="overflow-hidden overflow-y-auto max-h-[400px]">
          {history.length > 0 ? (
            <ul className="divide-y divide-gray-200 dark:divide-gray-700">
              {history.map((item) => (
                <li key={item.id} className="py-3">
                  <div className="flex justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                        {item.fromAmount.toFixed(2)} {item.fromCurrency} → {item.toAmount.toFixed(2)} {item.toCurrency}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {formatTimestamp(item.timestamp)}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 h-6 w-6"
                      onClick={() => onRemoveItem(item.id)}
                    >
                      <X className="h-4 w-4" />
                      <span className="sr-only">Remove</span>
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="py-8 text-center">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800">
                <svg
                  className="h-6 w-6 text-gray-400 dark:text-gray-500"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <p className="mt-4 text-gray-500 dark:text-gray-400">No conversion history yet</p>
              <p className="text-sm text-gray-400 dark:text-gray-500">Your conversions will appear here</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
