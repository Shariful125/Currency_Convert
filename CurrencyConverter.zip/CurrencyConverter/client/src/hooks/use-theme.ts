import { useTheme as useThemeContext } from "@/components/ui/theme-provider";

export function useTheme() {
  return useThemeContext();
}
